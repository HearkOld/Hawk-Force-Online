﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="pt-br" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Register</title>
<style type="text/css">
.style6 {
	text-align: center;
}
.style2 {
	text-align: right;
	font-family: Tahoma;
	font-size: small;
}
.style3 {
	text-align: left;
	font-family: Tahoma;
	font-size: small;
}
.style4 {
	text-align: center;
	font-family: Tahoma;
	font-size: small;
}
</style>
</head>

<body>

<form action="modules/registering.php" method="post">
	<div class="style6">

<table align="center" style="width: 46%">
	<tr>
		<td class="style4" colspan="2"><strong>Required Informations</strong></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Username:</td>
		<td class="style3">
		<input maxlength="12" name="username_box" style="width: 120px" type="text" size="12" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Password:</td>
		<td class="style3">
		<input maxlength="12" name="password1_box" style="width: 120px" type="password" size="12" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Confirm Passowrd:</td>
		<td class="style3">
		<input maxlength="12" name="password2_box" style="width: 120px" type="password" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Email Adress:</td>
		<td class="style3">
		<input name="email_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Secret Question:</td>
		<td class="style3">
		<input maxlength="12" name="question_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Secret Answer:</td>
		<td class="style3">
		<input maxlength="12" name="answer_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style4" colspan="2"><strong>Optional Informations</strong></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Name:</td>
		<td class="style3">
		<input name="name_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Last Name:</td>
		<td class="style3">
		<input name="lastname_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Date of Birth:</td>
		<td class="style3">
		<input name="birth_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Gender:</td>
		<td class="style3">
		<select name="gender_box" style="width: 120px">
		<option selected="selected">Male</option>
		<option>Female</option>
		</select></td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">Country:</td>
		<td class="style3"><select name="country_box" style="width: 120px">
		<option></option>
		<option>Brasil</option>
		<option>United States</option>
		</select></td>
	</tr>
	<tr>
		<td class="style4" colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td class="style2" style="width: 168px">&nbsp;</td>
		<td class="style3">
		<input name="Button" type="submit" value="Create Account" /></td>
	</tr>
</table>

	</div>
</form>

</body>

</html>
