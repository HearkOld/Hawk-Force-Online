﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="pt-br" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Recover Password</title>
<style type="text/css">
.style1 {
	text-align: center;
}
.style2 {
	text-align: right;
	font-family: Tahoma;
	font-size: small;
}
.style3 {
	text-align: left;
	font-family: Tahoma;
	font-size: small;
}
</style>
</head>

<body>

<form action="modules/recoveringpass.php" method="post">
	<div class="style1">

<table align="center" style="width: 54%">
	<tr>
		<td class="style2" style="width: 175px">Username:</td>
		<td class="style3">
		<input name="username_box" style="width: 120px" type="text" size="12" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 175px">Secret Question:</td>
		<td class="style3">
		<input name="question_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 175px">Secret Answer:</td>
		<td class="style3">
		<input name="answer_box" style="width: 120px" type="text" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 175px">New Password:</td>
		<td class="style3">
		<input name="password1_box" style="width: 120px" type="password" size="12" /></td>
	</tr>
	<tr>
		<td class="style2" style="width: 175px">Confirm New Password</td>
		<td class="style3">
		<input name="password2_box" style="width: 120px" type="password" size="12" /></td>
	</tr>
	<tr>
		<td class="style2" colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td class="style2" style="width: 175px; height: 20px"></td>
		<td class="style3" style="height: 20px">
		<input name="Button" type="submit" value="Recover Password" /></td>
	</tr>
</table>

	</div>
</form>

</body>

</html>
