﻿<?php

$database = "D:\\RPG Maker\\Projetos\\Net Gaming\\Server\\Database.sdf";
$password = "";
$md5_encryption = true;

$sql = new COM("ADODB.Connection") or die("Cannot connect to Database"); 
$sql->Open("Provider=Microsoft.SQLSERVER.CE.OLEDB.3.5;Data Source=$database;SSCE:Database Password=$password");

$forbidden_strings = array(";","'","\"","*","union","del","DEL","insert","update","=","drop","sele","$");
?>