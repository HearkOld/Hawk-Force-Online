﻿<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
</head>

<?php

include "config.php";

$username	= $_POST['username_box'];
$password1	= $_POST['password1_box'];
$password2	= $_POST['password2_box'];
$email		= $_POST['email_box'];
$question	= $_POST['question_box'];
$answer		= $_POST['answer_box'];
$name		= $_POST['name_box'];
$lastname	= $_POST['lastname_box'];
$birth		= $_POST['birth_box'];
$gender		= $_POST['gender_box'];
$country	= $_POST['country_box'];

$username_check = $sql->Execute("SELECT * FROM Accounts WHERE Username = '$username'");
$email_check    = $sql->Execute("SELECT * FROM Accounts WHERE Email = '$email'");

foreach($_POST as $value)
foreach($forbidden_strings as $word)
if(substr_count($value, $word) > 0) {
echo "<script>alert('Do not use special characters!'); top.location=\"/register.php\"</script>";
}

if (empty($username)) {
echo "<script>alert('Invalid Username!'); top.location=\"/register.php\"</script>";
}
elseif (strlen($username) < 6) {
echo "<script>alert('The Username must have 6 characters or more!'); top.location=\"/register.php\"</script>";
}
elseif (!$username_check->EOF) {
echo "<script>alert('This Username is already in use!'); top.location=\"/register.php\"</script>";
}
elseif (empty($password1)) {
echo "<script>alert('Invalid Password!'); top.location=\"/register.php\"</script>";
}
elseif (strlen($password1) < 6) {
echo "<script>alert('The Password must have 6 characters or more!'); top.location=\"/register.php\"</script>";
}
elseif (empty($password2) || $password1 != $password2) {
echo "<script>alert('The Passwords does not match!'); top.location=\"/register.php\"</script>";
}
elseif (empty($email)) {
echo "<script>alert('Invalid Email!'); top.location=\"/register.php\"</script>";
}
elseif (!$email_check->EOF) {
echo "<script>alert('This Email is already in use!'); top.location=\"/register.php\"</script>";
}
elseif (empty($question)) {
echo "<script>alert('Invalid Secret Question!'); top.location=\"/register.php\"</script>";
}
elseif (empty($answer)) {
echo "<script>alert('Invalid Secret Answer!'); top.location=\"/register.php\"</script>";
}
else {
if($md5_encryption) { $password = MD5($password1); } else { $password = $password1; }
$date = date('Y/m/d G:i:s');
$sql->Execute("INSERT INTO Accounts (Username, Password, Email, Secret_Question, Secret_Answer, Register_Date, Name, Last_Name, Gender, Country) VALUES ('$username', '$password', '$email', '$question', '$answer', '$date', '$name', '$lastname', '$gender', '$country')");
echo "<script>alert('Account registered successfully!'); top.location=\"/index.php\"</script>";
}

?>