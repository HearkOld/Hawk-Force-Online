﻿<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">

<?php

include("config.php");

$username	= $_POST['username_box'];
$question	= $_POST['question_box'];
$answer		= $_POST['answer_box'];
$password1	= $_POST['password1_box'];
$password2	= $_POST['password2_box'];

$username_check = $sql->Execute("SELECT * FROM Accounts WHERE Username = '$username'");
$question_check = $sql->Execute("SELECT * FROM Accounts WHERE Secret_Question  = '$question'");
$answoer_check  = $sql->Execute("SELECT * FROM Accounts WHERE Secret_Answer = '$answer'");

foreach($_POST as $value)
foreach($forbidden_strings as $word)
if(substr_count($value, $word) > 0) {
echo "<script>alert('Do not use special characters!'); top.location=\"/register.php\"</script>";
}

if (empty($username)) {
echo "<script>alert('Invalid Username!'); top.location=\"/recoverpass.php\"</script>";
}
elseif ($username_check->EOF) {
echo "<script>alert('This user does not exist!'); top.location=\"/recoverpass.php\"</script>";
}
elseif (empty($question) || !$question_check->EOF) {
echo "<script>alert('Incorrect Secret Question!'); top.location=\"/recoverpass.php\"</script>";
}
elseif (empty($answer) || !$answoer_check->EOF) {
echo "<script>alert('Incorrect Secret Answer!'); top.location=\"/recoverpass.php\"</script>";
}
elseif (empty($password1)) {
echo "<script>alert('Invalid Password!'); top.location=\"/recoverpass.php\"</script>";
}
elseif (strlen($password1) < 6) {
echo "<script>alert('The Password must have 6 characters or more!'); top.location=\"/register.php\"</script>";
}
elseif (empty($password2) || $password1 != $password2) {
echo "<script>alert('The Passwords does not match!'); top.location=\"/recoverpass.php\"</script>";
}
else {
if($md5_encryption) { $password = MD5($password1); } else { $password = $password1; }
$sql->Execute("UPDATE Accounts SET Password = '$password ' WHERE Username = '$username'");
echo "<script>alert('Password Changed!'); top.location=\"/index.php\"</script>";
}

?>

</head>

