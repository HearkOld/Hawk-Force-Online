﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="pt-br" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link rel="SHORTCUT ICON" href="./images/favicon.ico"/>
<title>Home</title>
<style type="text/css">
.style2 {
	text-align: center;
}
.style3 {
	text-align: center;
	font-family: Verdana;
	font-size: small;
}
.style4 {
	font-family: Verdana;
	font-size: small;
}
</style>
</head>

<body>

<form method="post">
	<div class="style2">
	<input height="80" name="Logo" src="images/Vampyr.png" type="image" width="320" class="style4" /></div>
</form>
<p class="style3"><a href="register.php">Register</a>&nbsp;&nbsp;
<a href="recoverpass.php">Recover Password</a></p>

</body>

</html>
